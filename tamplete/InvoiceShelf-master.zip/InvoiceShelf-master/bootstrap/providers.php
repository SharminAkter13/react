<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    App\Providers\DropboxServiceProvider::class,
    App\Providers\ViewServiceProvider::class,
    App\Providers\PDFServiceProvider::class,
    App\Providers\AppConfigProvider::class,
];
