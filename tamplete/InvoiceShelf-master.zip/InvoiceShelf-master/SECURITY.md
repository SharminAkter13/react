# Security Policy

## Reporting a Vulnerability

Please email security@invoiceshelf.com to report any security vulnerabilities. We will acknowledge receipt of your vulnerability and strive to send you regular updates about our progress. If you're curious about the status of your disclosure please feel free to email us again.
